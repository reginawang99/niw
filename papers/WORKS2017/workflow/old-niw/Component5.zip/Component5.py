#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
with open(sys.argv[1],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        x = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        x = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            x = True
        else:
            x = False
    elif arr[7:12] == 'float':
        x = float(arr[arr.find('>')+1:])
    else:
        x = eval(arr[arr.find('>')+1:])
db = pd.read_csv("data-modified.csv")
db["Date"] = db["Date"].apply(pd.to_datetime)
f = plt.figure(figsize=(10, 6))
ax = f.add_subplot(111)
x, y = db["lon"], db["lat"]
s = plt.scatter(x, y, marker=".", color="k")
for d, day in db.set_index("Date").groupby(lambda x: x.day):
    x, y = day["lon"], day["lat"]
    c = cm.Set1(d/30.)
    s = plt.scatter(x, y, marker="^", color=c, label=str(d), s=20)
ax.get_yaxis().set_visible(False)
ax.get_xaxis().set_visible(False)
plt.legend(loc=2)
plt.title("Spatial distribution of events by day")
ax.set_axis_bgcolor("0.2")
with open(sys.argv[2],"w") as w392075:
    try:
        w392075.write(str(type(x))+'\n')
        w392075.write(str(x))
    except: pass
with open(sys.argv[3],"w") as w392075:
    try:
        w392075.write(str(type(y))+'\n')
        w392075.write(str(y))
    except: pass
with open(sys.argv[4],"w") as w392075:
    try:
        w392075.write(str(type(day))+'\n')
        w392075.write(str(day))
    except: pass
with open(sys.argv[5],"w") as w392075:
    try:
        w392075.write(str(type(c))+'\n')
        w392075.write(str(c))
    except: pass
try:savefig(sys.argv[])
except:pass6