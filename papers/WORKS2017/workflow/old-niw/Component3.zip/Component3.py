#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
def parse_loc(loc, ret_lon=True):
    try:
        lon, lat = loc.split(",")
        lon, lat = lon.strip(' '), lat.strip(' ')
        lon, lat = map(float, [lon, lat])
        if ret_lon:
            return lon
        else:
            return lat
    except:
        return None
with open(sys.argv[1],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        db = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        db = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            db = True
        else:
            db = False
    elif arr[7:12] == 'float':
        db = float(arr[arr.find('>')+1:])
    else:
        db = eval(arr[arr.find('>')+1:])
db["lon"] = db["Location (approximate)"].apply(lambda x: parse_loc(x))
db["lat"] = db["Location (approximate)"].apply(lambda x: parse_loc(x, ret_lon=False))
db["Date"] = db["Date"].apply(pd.to_datetime)
db.to_csv("data-modified.csv")
db.head()
with open(sys.argv[2],"w") as w392075:
    try:
        w392075.write(str(type(x))+'\n')
        w392075.write(str(x))
    except: pass