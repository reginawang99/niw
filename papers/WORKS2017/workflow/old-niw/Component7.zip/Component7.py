#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
with open(sys.argv[4],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        c = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        c = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            c = True
        else:
            c = False
    elif arr[7:12] == 'float':
        c = float(arr[arr.find('>')+1:])
    else:
        c = eval(arr[arr.find('>')+1:])
with open(sys.argv[3],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        day = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        day = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            day = True
        else:
            day = False
    elif arr[7:12] == 'float':
        day = float(arr[arr.find('>')+1:])
    else:
        day = eval(arr[arr.find('>')+1:])
with open(sys.argv[2],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        y = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        y = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            y = True
        else:
            y = False
    elif arr[7:12] == 'float':
        y = float(arr[arr.find('>')+1:])
    else:
        y = eval(arr[arr.find('>')+1:])
with open(sys.argv[1],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        x = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        x = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            x = True
        else:
            x = False
    elif arr[7:12] == 'float':
        x = float(arr[arr.find('>')+1:])
    else:
        x = eval(arr[arr.find('>')+1:])
db = pd.read_csv("data-modified.csv")
db["Date"] = db["Date"].apply(pd.to_datetime)
bg = cimgt.OSM()
src = ccrs.PlateCarree()
f = plt.figure(figsize=(20, 30))
ax = plt.axes(projection=bg.crs)
ax.add_image(bg, 9, alpha=0.5)
x, y = db["lon"], db["lat"]
extent = [y.min(), y.max(), x.min(), 34]
extent = [34, 36, x.min(), x.max()]#Manually tweaked
for d, day in db.set_index("Date").groupby(lambda x: x.day):
    y, x = day["lon"], day["lat"]
    c = cm.Set1(d/30.)
    s = plt.scatter(x, y, marker="^", color=c, label=str(d), s=40, transform=src)
ax.set_extent(extent, crs=src)
plt.legend(loc=2)
plt.title("Spatial distribution of events by day")
plt.show()
try:savefig(sys.argv[])
except:pass5