#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
# Trick from http://stackoverflow.com/questions/7800213/can-i-use-pythons-csv-reader-with-google-fusion-tables
api =str(sys.argv[1])
request =str(sys.argv[2])
query =str(sys.argv[3])
url = "%s?%s" % (request_url, urllib.urlencode({"sql": query, "key": api_key}))
serv_req = urllib2.Request(url=url)
serv_resp = urllib2.urlopen(serv_req)
table = serv_resp.read()
print "\nLast pull of data from the Google FusionTable: ", datetime.datetime.now()
csv = simplejson.loads(table)
del csv["kind"]
csv["data"] = csv["rows"]
del csv["rows"]
db = pd.read_json(simplejson.dumps(csv), orient="split")
db.to_csv("data.csv", header=True, index=False, encoding="utf-8")