#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
with open(sys.argv[2],"r") as r:
    arr = r.read()
    if arr[7:10]== 'int':
        x = int(arr[arr.find('>')+1:])
    elif arr[7:10] == 'str':
        x = arr[arr.find('>')+1:]
    elif arr[7:11] == 'bool':
        if arr.replace(' ','')[-4:] == 'True':
            x = True
        else:
            x = False
    elif arr[7:12] == 'float':
        x = float(arr[arr.find('>')+1:])
    else:
        x = eval(arr[arr.find('>')+1:])
db = pd.read_csv("data-modified.csv")
db["Date"] = db["Date"].apply(pd.to_datetime)
with open(sys.argv[1],"r") as r3920n5:
    t = eval(r3920n5.read())
t = t.reindex(t)
by_day = t.groupby(lambda x: x.day).size()
by_day.plot(kind="bar")
plt.title("Number of events by day")
plt.show()
with open(sys.argv[3],"w") as w392075:
    try:
        w392075.write(str(type(x))+'\n')
        w392075.write(str(x))
    except: pass