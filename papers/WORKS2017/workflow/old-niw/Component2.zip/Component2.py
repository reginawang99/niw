#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
db = pd.read_csv("data.csv")
with open(sys.argv[1],"w") as w392075:
    try:
        w392075.write(str(type(db))+'\n')
        w392075.write(str(db))
    except: pass