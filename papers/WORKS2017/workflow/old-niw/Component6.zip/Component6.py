#!/usr/bin/env python
import matplotlib
matplotlib.use("Agg")
import sys
import simplejson
import matplotlib.pyplot as plt
import datetime
import urllib2, urllib
import pandas as pd
import matplotlib.cm as cm
import cartopy.crs as ccrs
import cartopy.io.img_tiles as cimgt
# You'll need cartopy for a pretty map